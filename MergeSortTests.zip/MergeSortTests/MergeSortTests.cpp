#include "pch.h"
#include "CppUnitTest.h"
#include "C:\Users\user\source\repos\ConsoleApplication1/merge_sort.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace MergeSortUnitTests
{
    TEST_CLASS(MergeSortTests)
    {
    public:

        TEST_METHOD(EmptyArray)
        {
            MergeSort ms;
            std::vector<int> arr;
            ms.sort(arr);
            Assert::IsTrue(arr.empty());
        }

        TEST_METHOD(SingleElement)
        {
            MergeSort ms;
            std::vector<int> arr = { 42 };
            ms.sort(arr);
            Assert::AreEqual(42, arr[0]);
        }

        TEST_METHOD(ReverseArray)
        {
            MergeSort ms;
            std::vector<int> arr = { 5, 4, 3, 2, 1 };
            ms.sort(arr);
           
            std::vector<int> expected = { 1, 2, 3, 4, 5 };
            Assert::IsTrue(arr == expected);
        }

        TEST_METHOD(Duplicates)
        {
            MergeSort ms;
            std::vector<int> arr = { 3, 1, 3, 1 };
            ms.sort(arr);

            std::vector<int> expected = { 1, 1, 3, 3 };
            Assert::IsTrue(arr == expected);
        }
    };
}
