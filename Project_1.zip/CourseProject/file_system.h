#pragma once

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <locale>

#include "get_int.h"
#include "functions.h"

using namespace std;

bool file_input(vector<int>& arr);

void file_output(vector<int>& arr);