#pragma once

#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <ctime>
#include <iomanip>

#include "get_int.h"

using namespace std;

void manual_input(vector<int>& arr);
void randomArray(vector<int>& arr);
void PrintArray(vector<int>& matrix);
vector<int> sortArray(vector<int>& arr);

class ISort {
protected:
	int comparisons;
	int swaps;

public:
	ISort() : comparisons(0), swaps(0) {}
	virtual ~ISort() {}

	virtual void Sort(vector<int>& matrix) = 0;

	int getComparisons() const { return comparisons; }
	int getSwaps() const { return swaps; }
	void ResetCounters() { comparisons = 0; swaps = 0; }
};

class BubbleSort : public ISort {
public:
	void Sort(vector<int>& matrix) override {
		
		bool swapped = false;
		for (size_t i = 0; i < matrix.size() - 1; ++i) {
			swapped = false;
			for (size_t j = 0; j < matrix.size() - i - 1; ++j) {
				comparisons++;
				if (matrix[j] > matrix[j + 1]) {
					swap(matrix[j], matrix[j + 1]);
					swaps++;
					swapped = true;
				}
			}
			if (!swapped) break;
		}
	}
};

class SelectionSort : public ISort {
public:
	void Sort(vector<int>& matrix) override {
		
		for (size_t i = 0; i < matrix.size() - 1; ++i) {
			size_t min_idx = i;
			for (size_t j = i + 1; j < matrix.size(); ++j) {
				comparisons++;
				if (matrix[j] < matrix[min_idx]) {
					min_idx = j;
				}
			}
			if (min_idx != i) {
				swap(matrix[i], matrix[min_idx]);
				swaps++;
			}
		}
	}
};

class InsertionSort : public ISort {
public:
	void Sort(vector<int>& matrix) override {
		
		for (size_t i = 1; i < matrix.size(); ++i) {
			int key = matrix[i];
			int j = static_cast<int>(i) - 1;

			while (j >= 0 && matrix[j] > key) {
				comparisons++;
				matrix[j + 1] = matrix[j];
				swaps++;
				j--;
			}
			comparisons++;
			if (j + 1 != static_cast<int>(i)) {
				matrix[j + 1] = key;
				swaps++;
			}	
		}
	}
};

class ShellSort : public ISort {
public:
	void Sort(vector<int>& matrix) override {
		
		for (size_t gap = matrix.size() / 2; gap > 0; gap /= 2) {
			for (size_t i = gap; i < matrix.size(); ++i) {
				int temp = matrix[i];
				size_t j;

				for (j = i; j >= gap; j -= gap) {
					comparisons++;
					if (matrix[j - gap] > temp) {
						matrix[j] = matrix[j - gap];
						swaps++;
					}
					else {
						break;
					}
				}
				matrix[j] = temp;
				if (j != i) swaps++;
			}
		}
	}
};

class QuickSort : public ISort {
public:
	void Sort(vector<int>& matrix) override {
		quickSort(matrix, 0, static_cast<int>(matrix.size()) - 1);
	}
private:
	void quickSort(vector<int>& arr, int low, int high) {
		if (low < high) {
			int pi = partition(arr, low, high);
			quickSort(arr, low, pi - 1);
			quickSort(arr, pi + 1, high);
		}
	}

	int partition(vector<int>& arr, int low, int high) {
		int pivot = arr[high];
		int i = low - 1;

		for (int j = low; j <= high - 1; ++j) {
			comparisons++;
			if (arr[j] < pivot) {
				i++;
				swap(arr[i], arr[j]);
				swaps++;
			}
		}
		swap(arr[i + 1], arr[high]);
		swaps++;
		return i + 1;
	}
};

class MergeSort : public ISort {
public:
	void Sort(vector<int>& arr) override {
		mergeSort(arr, 0, static_cast<int>(arr.size()) - 1);
	}
private:
	void mergeSort(vector<int>& arr, int left, int right) {
		if (left < right) {
			int mid = left + (right - left) / 2;

			mergeSort(arr, left, mid);
			mergeSort(arr, mid + 1, right);

			merge(arr, left, mid, right);
		}
	}

	void merge(vector<int>& arr, int left, int mid, int right) {
		int n1 = mid - left + 1;
		int n2 = right - mid;

		vector<int> leftArr(n1), rightArr(n2);

		for (int i = 0; i < n1; i++) {
			leftArr[i] = arr[left + i];
		}
		for (int j = 0; j < n2; j++) {
			rightArr[j] = arr[mid + 1 + j];
		}

		int i = 0, j = 0, k = left;

		while (i < n1 && j < n2) {
			comparisons++;
			if (leftArr[i] <= rightArr[j]) {
				arr[k] = leftArr[i];
				i++;
			}
			else {
				arr[k] = rightArr[j];
				j++;
				swaps++;
			}
			k++;
		}

		while (i < n1) {
			arr[k] = leftArr[i];
			i++;
			k++;
			swaps++;
		}

		while (j < n2) {
			arr[k] = rightArr[j];
			j++;
			k++;
			swaps++;
		}
	}
};