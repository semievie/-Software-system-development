#include "pch.h"
#include "../CourseProject/file_system.h"

TEST(SortingTest, Test_1) {
	vector<int> arr = {-1, 2, 0, -5, 6};
	vector<int> expected = {-5, -1, 0, 2, 6};
	ISort* sort = new MergeSort();
	sort->Sort(arr);
	delete sort;
	EXPECT_EQ(arr, expected);
}

TEST(SortingTest, Test_2) {
	vector<int> arr = { -1, 2, 0, -5 };
	vector<int> expected = { -5, -1, 0, 2 };
	ISort* sort = new MergeSort();
	sort->Sort(arr);
	delete sort;
	EXPECT_EQ(arr, expected);
}

TEST(SortingTest, Test_3) {
	vector<int> arr = { -1, 2, 0, -5, -6 };
	vector<int> expected = { -6, -5, -1, 0, 2 };
	ISort* sort = new MergeSort();
	sort->Sort(arr);
	delete sort;
	EXPECT_EQ(arr, expected);
}

TEST(SortingTest, Test_4) {
	vector<int> arr = { -1, 2 };
	vector<int> expected = { -1, 2 };
	ISort* sort = new MergeSort();
	sort->Sort(arr);
	delete sort;
	EXPECT_EQ(arr, expected);
}

TEST(SortingTest, Test_5) {
	vector<int> arr = { 0, -5, 6 };
	vector<int> expected = { -5, 0, 6 };
	ISort* sort = new MergeSort();
	sort->Sort(arr);
	delete sort;
	EXPECT_EQ(arr, expected);
}